package com.frutilla.models.venta;

public enum FormaDePago{
    TARJETA_CREDITO, TARJETA_DEBITO, PLIN, YAPE
}

package com.frutilla.models.inventario;

public enum TipoEstado{
	DISPONIBLE, AGOTADO
}

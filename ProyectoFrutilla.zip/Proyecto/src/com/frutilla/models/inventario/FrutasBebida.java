package com.frutilla.models.inventario;

//lista preliminar en base a conocimiento comun

public enum FrutasBebida {
    PAPAYA, MANGO, LUCUMA, FRESA, PINHA, PLATANO, MANZANA, PERA
}

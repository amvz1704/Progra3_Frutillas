package com.frutilla.models.inventario; 

//en java automaticamente es null un enum

public enum TipoLeche{
	ENTERA, SIN_LACTOSA
}
